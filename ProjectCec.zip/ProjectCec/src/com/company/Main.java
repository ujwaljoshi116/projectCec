package com.company;

public class Main {

    public static void main(String[] args) {
	    //Printing line in terminal
        System.out.println("Hellp World");

        //Assigning variables
        String name ="Hello Ujwal Here";
        System.out.println(name);


        //DataTypes
        int a = 52;
        // float will print decimal values or point values
        float b =42.5f;
        //boolean gives output either true or false
        boolean isAdult = true;
        char grd = 'A';
        //byte code will run because number 5 is in range.If the range exceeds it occurs a error
        //Same as we have long  datatype as well
        byte x = 5;
        double c =25.255;
        //Short code will print the nuber because the valuse falls in its range
        short e =25276;

        System.out.println(a);
        System.out.println(b);
        System.out.println(isAdult);
        System.out.println(grd);
        System.out.println(x);
        System.out.println(c);
        System.out.println(e);


        //Arithmetic Operators

        int num1 =25 , num2 = 26;

        System.out.println("The Addtion of num1 and num2 is:");
        System.out.println(num1 + num2);

        System.out.println("The Subtraction of num1 and num2 is:");
        System.out.println(num1 - num2);

        System.out.println("The Divide of num1 and num2 is:");
        System.out.println(num1 / num2);

        System.out.println("The Multiple of num1 and num2 is:");
        System.out.println(num1 * num2);

        System.out.println("The Module of num1 and num2 is:");
        System.out.println(num1 % num2);



        //Conditional statements
        if (500 < 1000)
        {
            System.out.println("500 is smaller than 1000");
        }


        //if else

        int age = 18;
        //checking the age
        if(age >= 18)
        {
            System.out.print("Eligible to vote");
        }else
            {
            System.out.println("not Eligible to vote");
        }


        //Types of commenting in java ide:

        //Three tpyes of commenting lines(1.Single line,2.Paragraph comment,3.Documentation comment)

        //This type of double forward slash are single line comment

        /*
        This type of shlash is used to comment a whole paragraph of code.
         */

        /**
         * This type of commenting is known as documentation comment
         * we can comment description of code in it by name of auther
         * example:
         * @ ujwal
        /** Naming convention in Java:
         * Class name should always start with uppercase letter(for EG. public class Main)
         * Method name should always start with lowercase letter(for EG. println())
         * Variable name should always start with lowercase letter,if name contains multiple words,It should start with
           the lowercase letter followed by an uppercase letter(for EG.fName)
         * lowercase letter followed by an uppercase letter is  known as CamelCase.

         */


    }
}
